function ll=MVNCTloglik(param,x,bound)

    % if there is no bound, add a bound
    if nargin<3, bound=0; end
    
    % if the bound is structured adjust the standard error
    if isstruct(bound), param=einschrk(real(param),bound,999); end

    [nobs,d]=size(x);
    
    Sigma=zeros(d,d); 
    
    mu1 = param(1);
    mu2 = param(2);
    g1  = param(3);
    g2  = param(4);
    nu  = param(5);

    Sigma(1,1)=param(6);
    Sigma(2,2)=param(8);
    Sigma(1,2)=param(7); Sigma(2,1)=Sigma(1,2);
    
    % if min eigenvalue of Sig is very small
    if 0 % min(eig(Sigma))<1e-10
        ll=1e5;
    else
        pdf=zeros(nobs,1);
        for i=1:nobs, pdf(i) = mvnctpdfln(x(i,:)', [mu1,mu2], [g1,g2], nu, Sigma); end
        llvec = pdf; % llvec=log(pdf); 
        ll=-mean(llvec); if isinf(ll), ll=1e5; end
    end