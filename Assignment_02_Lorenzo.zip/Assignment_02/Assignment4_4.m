% Assignment 4.4

load('/MATLAB Drive/SFF/Assignment_02/Data/DJIA30stockreturns.mat')
size(DJIARet)

%%

reps = 50;

nStocks = 25;
unif = ones([1 nStocks]) * (1/nStocks);
AICs = zeros([reps 2]);
BICs = zeros([reps 2]);

for rep = 1:reps
    disp(['Step: ', num2str(rep)])
    % You can of course use more than 50! Please try if feasible.
    % And, you do not need to worry if you draw the same pair.
    % With unlimited computing resources, you would choose,
    % say, 1000 pairs. 

    % 1. Randomly draw 2 out of the 25 stocks,
    s1 = randmultinomial(unif);
    s2 = drawNew(s1,unif); % NB: two different stocks

    tsTwoStocks = DJIARet(:,[s1,s2]);

    % 2. Fit the Mix-Lap and the NCT; store their AIC and BIC values
    [mleLaplace,mleNCT,aic,bic] = mvMixLaplaceNCTestimation(tsTwoStocks);

    % [aicLaplace, aicNCT]
    AICs(rep,:) = aic;
    % [bicLaplace, bicNCT]
    BICs(rep,:) = bic;

end

% Output of the function:

% 1. The 50 X 4 table of AIC and BIC values, for each of the two distributional models.

tab = array2table([AICs,BICs],"VariableNames",["AIC Laplace","AIC NCT","BIC Laplace","BIC NCT"], "RowNames",string(1:50));

time = clock;
save("/MATLAB Drive/SFF/Assignment_02/Data/A4_2_AICBIC_" + cell2mat(arrayfun(@num2str, [time(1:5),round(time(6))], 'UniformOutput', false)) + ".mat", 'tab')

% According to AIC (BIC), the mix-lap is preferred in 42% (58%) of the cases.
r1 = sum(AICs(:,1) < AICs(:,2)) / size(AICs,1);
r2 = sum(BICs(:,1) < BICs(:,2)) / size(BICs,1);

% 2. A *smart plot* (everything should be totally clear by just looking at it) comparing the AIC values. And then, similar, for BIC.

figure(1)
plot(AICs)
legend(["Laplace","NCT"])
title("AICs Comparison between Laplace & NCT Distributions")
ylabel("AIC")

figure(2)
temp = sort(AICs);
plot(temp)
legend(["Laplace","NCT"])
title("AICs Comparison between Laplace & NCT Distributions")
ylabel("AIC")

figure(3)
plot(BICs)
legend(["Laplace","NCT"])
title("BICs Comparison between Laplace & NCT Distributions")
ylabel("BIC")

figure(4)
temp = sort(BICs);
plot(temp)
legend(["Laplace","NCT"])
title("BICs Comparison between Laplace & NCT Distributions")
ylabel("BIC")



