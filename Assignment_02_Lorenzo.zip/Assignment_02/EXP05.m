
% (0)
n = 10000;
y = zeros(n, 2);
b1 = 3;
b2 = 4;
lambda = 0.7;
mu1 = [5;4.5];
mu2 = [0.2;-0.1];
Sigma1 = [5,.75;.75,4];
Sigma2 = [1,.15;.15,2];

for i = 1:n
    h = rand > lambda;
    y(i,:) = laplacernd(1,b1,mu1,Sigma1).^h .* laplacernd(1,b2,mu2,Sigma2).^(1-h);
end

%%

% (1) Arbitrary values of b1 and b2 are chosen
b=[2,10];
% [solvec,crit,iter] = mixlaplaceEM_OUT(y,b); % NECESSARY

%%

% (2) The EM algorithm for the two-component multivariate mixture Laplace distribution is run
[solvec,crit,iter,H1] = mixlaplaceEM(y, b);

% (3) Using (14.44), those observations for which Ht,j = ht,j > 0.99 are assigned to component 1, otherwise to component 2
y1 = y(H1 > 0.99,:); y2 = y(H1 <= 0.99,:);

% (4) Estimates single-component multivariate Laplace distributions, for each of the two components, over a grid of b1 and b2 values
% (5) The optimal values of the bi are obtained from the two profile log-likelihoods

b = 1:.5:27.5;
est1 = zeros(5,1,length(b));
est2 = zeros(5,1,length(b));
ll1 = zeros(length(b),1);
ll2 = zeros(length(b),1);

for i=1:length(b)
    b(i)
    est1(:,:,i) = laplaceEM(y1,b(i));
    est2(:,:,i) = laplaceEM(y2,b(i));
    ll1(i) = mvLAPloglik(y1,b(i),est1(:,:,i));
    ll2(i) = mvLAPloglik(y2,b(i),est2(:,:,i));
end

%% (6) These optimal values of the bi are then used as the fixed values instead of those chosen in step (i), 
% and the iterative method is conducted again, starting with step (ii).
% This could be repeated "until convergence", but we use just two iterations.

b1_new = b(real(ll1) == max(real(ll1)));
b2_new = b(real(ll2) == max(real(ll2)));

b1_new
b2_new
