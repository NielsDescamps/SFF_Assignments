function y = mvlaplacelog(x,b,mu,Sigma)

% Log Likelihood of Multivariate Laplace

d=length(x);

if nargin<3, mu = []; end, if isempty(mu), mu = zeros(d,1); end

if nargin<4, Sigma = eye(d); end

x = reshape(x,d,1); mu = reshape(mu,d,1); m = (x-mu)' * inv(Sigma) * (x-mu);

% log likelihood from equation (14.31) of p. 650 of TS book

y = -0.5*log(det(Sigma)) - (d/2)*log(2*pi) + log(2) - log(gamma(b)) + (b/2-d/4)*log(m/2) + log(besselk(b-d/2,sqrt(2*m)));