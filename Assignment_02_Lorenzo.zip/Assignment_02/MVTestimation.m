function [param,stderr,iters,loglik,Varcov] = MVTestimation(x)

% param: (k, mu1, mu2, Sigma_11, Sigma_12, Sigma_22)

[nobs, d]=size(x); if d~=2, error('not done yet, use EM'), end

% define lower and upper bounds, x0 and 
if d==2
    %%%%%%%%        k   mu1  mu2 s11  s12 s22
    bound.lo    = [ .2 -1   -1   0.01 -90 0.01 ];
    bound.hi    = [ 20  1    1   90    90 90 ];
    bound.which = [ 1   0    0   1     1  1 ]; % for use in einschrk()
    initvec     = [ 2  -0.8 -0.2 20    2  10 ];
end

maxiter=300; tol=1e-7; MaxFunEvals=length(initvec)*maxiter;

opts=optimset('Display','iter','Maxiter',maxiter,'TolFun',tol,'TolX',tol,...
    'MaxFunEvals',MaxFunEvals,'LargeScale','Off');

% pout: values minimizing "fun"
% fval: value of the objective function "fun"
% theoutput: information about the optimization process
% hess: Hessian of "fun" at the solution "pout" (2nd order derivatives)
[pout,fval,~,theoutput,~,hess]= ...
    fminunc(@(param) MVTloglik(param,x,bound),einschrk(initvec,bound),opts);

V=inv(hess)/nobs; % Don't negate because we work with the negative of the loglik
[param,V]=einschrk(pout,bound,V); % transform and apply delta method to get V

param=param'; Varcov=V; stderr=sqrt(diag(V)); % Approximate standard errors
loglik=-fval*nobs; iters=theoutput.iterations;

function ll=MVTloglik(param,x,bound)

    % if there is no bound, add a bound
    if nargin<3, bound=0; end
    
    % if the bound is structured adjust the standard error
    if isstruct(bound), param=einschrk(real(param),bound,999); end

    [nobs, d]=size(x);
    
    Sig=zeros(d,d); k=param(1); 
    
    % Assume d=2
    mu=param(2:3);

    Sig(1,1)=param(4);
    Sig(2,2)=param(6);
    Sig(1,2)=param(5); Sig(2,1)=Sig(1,2);
    
    % if min eigenvalue of Sig is very small
    if min(eig(Sig))<1e-10
        ll=1e5;
    else
        pdf=zeros(nobs,1);
        for i=1:nobs, pdf(i) = mvtpdfmine(x(i,:),k,mu,Sig); end
        llvec=log(pdf); ll=-mean(llvec); if isinf(ll), ll=1e5; end
    end
