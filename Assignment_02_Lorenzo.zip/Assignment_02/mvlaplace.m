function y = mvlaplace(x,b,mu,sigma)

% PDF of Bivariate Laplace

d = min(size(x));

if nargin<3, mu = []; end, if isempty(mu), mu = zeros(d,1); end

if nargin<4, sigma = eye(d); end

% y = reshape(y, [2 n]);

m = diag((x' - mu).' * inv(sigma) * (x' - mu));

nominator = 2 * (m/2).^(b/2-1/2) .* besselk(b-1, sqrt(2*m));
    
denominator = sqrt(det(sigma)) * 2 * pi * gamma(b);
    
y = nominator / denominator;

end