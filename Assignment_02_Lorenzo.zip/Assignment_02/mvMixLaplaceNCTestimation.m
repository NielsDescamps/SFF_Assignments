function [mleLaplace,mleNCT,aic,bic] = mvMixLaplaceNCTestimation(x)

n = size(x,1);

[mleLaplace,~,~,loglikLaplace,~] = MVLaplaceMixEstimation(x);
[mleNCT,~,~,loglikNCT,~] = MVNCTestimation(x);

aicLaplace  = -2*loglikLaplace  + 2*6;
aicNCT      = -2*loglikNCT      + 2*8;
bicLaplace  = -2*loglikLaplace  + log(n)*6;
bicNCT      = -2*loglikNCT      + log(n)*8;

aic=[aicLaplace,aicNCT];
bic=[bicLaplace,bicNCT];