function s3 = drawNew(s1,unif)
    s2 = randmultinomial(unif);
    if s2 == s1
        s3 = randmultinomial(unif);
    else
        s3 = drawNew(s1,unif);
    end
end