%%% Assigment 3.1

%% Estimate Parameters through MLE

C   = [1 .5; .5 1];
df  = 5;
B   = 100;

df_hat  = zeros([B 1]);
mu1_hat = zeros([B 1]);
mu2_hat = zeros([B 1]);
s11_hat = zeros([B 1]);
s12_hat = zeros([B 1]);
s22_hat = zeros([B 1]);

for i = 1:B
    realisations= mvtrnd(C, df, 1000);
    params      = MVTestimation(realisations);
    df_hat(i)   = params(1);
    mu1_hat(i)  = params(2);
    mu2_hat(i)  = params(3);
    s11_hat(i)  = params(4);
    s12_hat(i)  = params(5);
    s22_hat(i)  = params(6);
end

%% Prepare Plot

params = vertcat(df_hat-5, mu1_hat, mu2_hat, s11_hat-1, s12_hat-.5, s22_hat-1);
temp1 = repelem("df", B);
temp2 = repelem("mu1", B);
temp3 = repelem("mu2", B);
temp4 = repelem("s11", B);
temp5 = repelem("s12", B);
temp6 = repelem("s22", B);
ind = vertcat(temp1', temp2', temp3', temp4', temp5', temp6');

%% Plot

figure(1)
boxplot(params, ind)
title('Boxplot - Parameters MLE of Bivariate Student t')
% hold on
% plot([0.001 10], [0 0], '--', 'Color', 'green', 'LineWidth', 1)
% legend('true ES')
% hold off

%% Assigment 3.1 %%

%% Simulate from a bivariate Student t

C   = [1 0; 0 1];
df  = 10;

realisations = mvtrnd(C, df, 10000);

params   = MVTestimation(realisations);
df_hat   = params(1);
mu1_hat  = params(2);
mu2_hat  = params(3);
s11_hat  = params(4);
s12_hat  = params(5);
s22_hat  = params(6);

weights = [.5; .5];

mu = [mu1_hat; mu2_hat];
sigma = [s11_hat s12_hat; s12_hat s22_hat];

a = weights;

%% Kernel Density

mu_S = a .* mu;
sigma_S = a' .* sigma .* a;

x = a' .* realisations;

%
% x(:, 3) = x(:, 1) + x(:, 2);
% x = sortrows(x, 3);
% x(:, 3) = [];
%

% manual pdf
denominator = gamma(df_hat/2) * df_hat * pi * sqrt(det(sigma_S));
nominator = @(x) gamma((df_hat+2)/2) * ( 1 + (x - mu_S)' * inv(sigma_S) * (x - mu_S) / df_hat )^(-(df_hat+2)/2);

myPDF = @(x) nominator(x) / denominator;

y = zeros([size(x, 1) 1]);

for i = 1:size(realisations, 1)
    
    y(i) = myPDF(x(i, :)');

end

xy1 = sortrows([sum(x, 2), y], 1);

plot(xy1(:,1), xy1(:,2));



%%

x = a' .* realisations;

x(:,1) = x(:,1) - mu1_hat * a(1);
x(:,2) = x(:,2) - mu2_hat * a(2);

x(:, 3) = x * a;
x = sortrows(x, 3);
x(:, 3) = [];

y = mvtpdf(x, a' .*sigma .* a, df_hat);

plot(sum(x, 2),y)

%%

nu=3;
x = [0; 0];

%
n = gamma((nu+2)/2) * (1 + x' * x / nu)^(-(nu+2)/2);
d = gamma(nu/2) * nu * pi;
n / d

%
mvtpdf(x, C, nu)

%
denominator = gamma(nu/2) * nu * pi * sqrt(det(C));
nominator = @(x) gamma((nu+2)/2) * ( 1 + (x - 0)' * inv(C) * (x - 0) / nu )^(-(nu+2)/2);

myPDF = @(x) nominator(x) / denominator;

myPDF(x)

%% Inverted Characteristic Function

% fun = @(t) exp(1i .* t .* mu_S) .* besselk(df/2, sqrt(df) .* abs(t) .* k) .* (sqrt(df) .* abs(t) .* k).^(df/2);
% integral(fun, -Inf, Inf) / denominator
% nomimator = exp(1i * t * mu_S) * besselk(df/2, df^.5 * abs(t) * k) * (df^.5 * abs(t) * k)^(df/2);

mu_S = a' * mu;
k = norm(sqrt(sigma) * a, 2);

denominator = gamma(df_hat/2) * 2^(df_hat/2 - 1);
nominator = @(t) exp(1i .* t .* mu_S) .* besselk(df_hat/2, sqrt(df_hat) .* abs(t) .* k) .* (sqrt(df_hat) .* abs(t) .* k).^(df_hat/2);

x = sort(realisations * a)';
x = a.' .* sort(realisations);

y = zeros([size(x, 2) 1]);

for i = 1:size(x, 2)

    xi = x(i);
    
    fun = @(t) exp(-1i .* t .* xi) .* nominator(t);
    
    temp = integral(fun, -Inf, Inf) / ( denominator * 2 * pi);

    y(i) = temp;

end

plot(x, y)

%% Experiment: C.25

t = 1;

comp1 = @(t) exp(1i * t' * mu);
comp2 = @(t) besselk(df_hat/2, norm(sqrt(df_hat) * sqrt(sigma) * t, 2)) * norm(sqrt(df_hat) * sqrt(sigma) * t, 2)^(df_hat/2);
comp3 = gamma(df_hat/2) * 2^(df_hat/2-1);

cfX = @(t) comp1(t) * comp2(t) / comp3;

cfS = @(t) cf(t) / denominator;

% cfS2 = @(t) exp(1i * t * mu_S) * besselk(df_hat/2, norm(sqrt(df_hat) * t * sqrt(sigma) * a, 2)) * norm(sqrt(df_hat) * t * sqrt(sigma) * a, 2)^(df_hat/2);




