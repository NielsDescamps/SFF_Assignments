function y=laplacernd(n,b,mu,Sigma)
% Multivatiate Laplace Random Number Generator
% Inputs:
%   n: number of rows
%   d: number of columns
%   mu: means vector (must have the length of d)
%   Sigma: variance vector (must have the length and width of d)

y = zeros(n,length(mu));

% Idea:
% G ~ Gam(b,1)
% (Y | G = g) ~ N_d(mu, g*Sigma)

for i=1:n
    % Every simulation must have a newly generated g value!
    g = gamrnd(b,1);
    y(i,:) = mvnrnd(mu,g*Sigma,1);
end