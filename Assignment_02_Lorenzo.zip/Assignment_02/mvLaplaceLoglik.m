function ll=mvLaplaceLoglik(x,b,param)
    
    Sigma=zeros(2,2);
    param = reshape(param,length(param),1);
    
    % Assume d=2
    mu=param(1:2);

    Sigma(1,1)=param(3);
    Sigma(2,1)=param(4); Sigma(1,2)=Sigma(2,1);
    Sigma(2,2)=param(5);
    
    % if min eigenvalue of Sigma is very small
    if min(eig(Sigma))<1e-10
        ll=1e5;
    else
        pdf=mvlaplace(x,b,mu,Sigma);
        llvec=log(pdf); ll=-mean(llvec); if isinf(ll), ll=1e5; end
    end

    ll = -ll * size(x,1);