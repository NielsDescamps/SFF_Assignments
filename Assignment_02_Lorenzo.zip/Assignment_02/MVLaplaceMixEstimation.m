function [param,stderr,iters,loglik,Varcov] = MVLaplaceMixEstimation(x)

% param: (b1, b2, mu1, mu2, m3, m4, Sigma_11, Sigma_12, Sigma_22, Sigma_33, Sigma_34, Sigma_44)

[nobs, d]=size(x); if d~=2, error('not done yet, use EM'), end

% define lower and upper bounds and x0
if d==2
    
    % estimate priors
    m1=min(x(:,1)); M1=max(x(:,1)); mid1=(m1+M1)/2; m2=min(x(:,2)); M2=max(x(:,2)); mid2=(m2+M2)/2;
    s=sqrt(cov(x)); s11=s(1,1); s12=s(1,2); s22=s(2,2); s33=s11/2; s34=s12/2; s44=s22/2;

    %%%%%%%%        b1  b2  mu1  mu2  m3   m4   s11 s12 s22 s33 s34 s44 lambda
    bound.lo    = [ 1   1   0    0    0    0    .01 -90 .01 .01 -90 .01 .001 ];
    bound.hi    = [ 30  30  0    0    0    0    90  90  90  90  90  90  .999 ];
    bound.which = [ 1   1   0    0    0    0    1   1   1   1   1   1   1    ]; % for use in einschrk()
    initvec     = [ 1.5 3.5 mid1 mid2 mid1 mid2 s11 s12 s22 s33 s34 s44 .6   ];
end

maxiter=300; tol=1e-7; MaxFunEvals=length(initvec)*maxiter;

opts=optimset('Display','iter','Maxiter',maxiter,'TolFun',tol,'TolX',tol,...
    'MaxFunEvals',MaxFunEvals,'LargeScale','Off');

% pout: values minimizing "fun"
% fval: value of the objective function "fun"
% theoutput: information about the optimization process
% hess: Hessian of "fun" at the solution "pout" (2nd order derivatives)
[pout,fval,~,theoutput,~,hess]= ...
    fminunc(@(param) mvMixLalplaceLoglik(param,x,bound),einschrk(initvec,bound),opts);

V=inv(hess)/nobs; % Don't negate because we work with the negative of the loglik
[param,V]=einschrk(pout,bound,V); % transform and apply delta method to get V

param=param'; Varcov=V; stderr=sqrt(diag(V)); % Approximate standard errors
loglik=-fval*nobs; iters=theoutput.iterations;

function ll=mvMixLalplaceLoglik(param,x,bound)

% if there is no bound, add a bound
if nargin<3, bound=0; end

% if the bound is structured adjust the standard error
if isstruct(bound), param=einschrk(real(param),bound,999); end

Sigma1=zeros(2,2);
Sigma2=zeros(2,2);

lambda=param(13); b1=param(1); b2=param(2);

mu1=param(3:4); mu2=param(5:6);

Sigma1(1,1)=param(7); Sigma1(1,2)=param(8); Sigma1(2,1)=Sigma1(1,2); Sigma1(2,2)=param(9);
Sigma2(1,1)=param(10); Sigma2(1,2)=param(11); Sigma2(2,1)=Sigma2(1,2); Sigma2(2,2)=param(12);

% if min eigenvalue of Sigma is very small
if (min(eig(Sigma1))<1e-10) || (min(eig(Sigma2))<1e-10)
    ll=1e5;
else
    % pdf=zeros(nobs,1);
    pdf=lambda*mvlaplace(x,b1,mu1',Sigma1) +(1-lambda)*mvlaplace(x,b2,mu2',Sigma2);
    % for i=1:nobs, pdf(i) = mvlaplace(x(i,:),b,mu,Sig); end
    llvec=log(pdf); ll=-mean(llvec); if isinf(ll), ll=1e5; end
end
