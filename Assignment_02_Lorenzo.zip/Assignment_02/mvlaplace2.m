function x = mvlaplace2(y, mu, sigma, b)
% PDF of Bivariate Laplace

n = size(y, 1);
x = zeros(n, 1);

% y = reshape(y, [2 n]);

for i=1:n
    % m is Standard Normally Distributed. Input it directly from out
    m = (y(i,:)' - mu)' * inv(sigma) * (y(i,:)' - mu);
    
    nominator = 2 * (m/2)^(b/2-1/2) * besselk(b-1, sqrt(2*m));
    
    denominator = sqrt(det(sigma)) * 2 * pi * gamma(b);
    
    x(i) = nominator / denominator;
end

end