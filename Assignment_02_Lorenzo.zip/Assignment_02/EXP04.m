% EXP04

% (0)
n = 1000;
y = zeros(n, 2);
b1 = 2;
b2 = 3;
mu1 = [5;5];
mu2 = [0;0];
Sigma1 = [5,0;0,3];
Sigma2 = [1,0;0,2];

for i = 1:n
    h = rand > 0.3;
    y(i,:) = laplacernd(1,2,b1,mu1,Sigma1).^h .* laplacernd(1,2,b2,mu2,Sigma2).^(1-h);
end

% (1) Arbitrary values of b1 and b2 are chosen
b=[2,3];

%%
% (2) The EM algorithm for the two-component multivariate mixture Laplace distribution is run
[solvec,crit,iter,H1] = mixlaplaceEM(y,b);
solvec

%% quasi-Bayesian
[solvec2,crit,iter,H1] = mixlaplaceEMqB(y,b);
solvec2

%%

n = 1000;
b = 6;
mu =[0;3];
Sigma = [5,0;0,1];

y = laplacernd(n,2,b,mu,Sigma);

para = laplaceEM(y,6);
para

%%
% Every bivariate simulation must have a newly generated g value!

n = 1000;
b = 10;
mu =[3;0];
Sigma = [5,0;0,3];

y = zeros(n,2);

for i=1:n
    g = gamrnd(b,1);
    y(i,:) = mvnrnd(mu, g*Sigma, 1);
end

%%

% gamrnd(a,b): generates a random number from the gamma distribution with the shape parameter a and the scale parameter b
b = 2;
g = gamrnd(b,1);

% mvnrnd(mu,Sigma,n)
mu =[0;0];
Sigma = [1,0;0,1];
mvnrnd(mu, g*Sigma, 1)

%%
y = csvread('/MATLAB Drive/SFF/Assignment_02/Data/simulations.csv',1,0);
size(y)

%%
% n = 1000;
% y = laprnd(n,2,0,1);

para = laplaceEM(y,10);
para