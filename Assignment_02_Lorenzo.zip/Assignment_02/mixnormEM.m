function [solvec,crit,iter] = mixnormEM(y,init,tol,maxit) 

if nargin < 4, maxit=5e4; end
if nargin < 3, tol=1e-6; end

outlier=0;

while 1
    % if there is no initial vector
    if nargin < 2
        % set a initial vector
        m=min(y); M=max(y); sd=std(y); mid=(m+M)/2; init = [mid mid sd/2 sd 0.6]';
    end

    [solvec,crit,iter] = hartley(y,init,tol,maxit);
    
    % if all estimated parameters are not NA: interrupt
    if all(~isnan(solvec)), break

    % else: eliminate outlier and restart
    else
        y=sort(y) ; left=y(2)-y(1); right=y(end)-y(end-1);
        if left>right , y=y(2:end); else y=y(1:end-1); end
        disp('removing an outlier ', outlier=outlier +1);
    end 
end

% Define "hartley" function
function [solvec,crit,iter] = hartley(y,init,tol,maxit)

old=init; new=zeros(5,1); iter=0; crit=0;

while 1
    iter=iter+1;
    
    mu1=old(1); mu2=old(2); s1=old(3); s2=old(4); lam=old(5);

    mixn = lam*normpdf(y,mu1,s1)+(1-lam)*normpdf(y,mu2,s2);
    
    H1=lam*normpdf(y,mu1,s1) ./ mixn; H2=1-H1; % (5.14)
    
    N1=sum(H1); N2=sum(H2);

    new(1) = sum(H1 .* y) / N1; new(2) = sum(H2 .* y) / N2; % (5.17.a)
    new(3) = sqrt ( sum(H1.*((y-new(1) ) .^2) ) / N1 ); new(4) = sqrt( sum(H2.*((y-new(2) ) .^2) ) / N2 ); % (5.17.b)
    new(5) = mean(H1); % (5.16)

    crit = max(abs(old-new)); solvec=new; if any(isnan(solvec)), break, end

    % conditions for interrupting
    if (crit < tol) || (iter >= maxit), break, end
    old=new;
end

