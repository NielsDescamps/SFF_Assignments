function ll=MVTloglik(param,x)

    % if there is no bound, add a bound
    if nargin<3, bound=0; end

    [nobs, d]=size(x);
    
    Sig=zeros(d,d); k=param(1);
    
    % Assume d=2
    mu=param(2:3);

    Sig(1,1)=param(4);
    Sig(2,2)=param(6);
    Sig(1,2)=param(5); Sig(2,1)=Sig(1,2);
    
    % if min eigenvalue of Sig is very small
    if min(eig(Sig))<1e-10
        ll=1e5;
    else
        pdf=zeros(nobs,1);
        for i=1:nobs, pdf(i) = mvtpdfmine(x(i,:),k,mu,Sig); end
        llvec=log(pdf); ll=-mean(llvec); if isinf(ll), ll=1e5; end
    end

    ll = -ll * size(x,1);