% Assigment 4.1

%% Normal Simulations

% PART 1: Prepare %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rng(123)

% Set basic parameters
n = 100000;
k = 2; % number of distributions which are part of the mixture

% Set parameters
lambda  = [.3 .7]; % prob. of taking each distribution
mu      = {[0; 0], [0; 0]};
sigma   = {[1 .25; .25 1]; [3 .75; .75 2.5]};
b       = [10, 5]; % MAKE SMALLER FOR PLOTTING

% Prepare mixture
pick=zeros(n,k);
for i=1:n
    c = randmultinomial(lambda);
    pick(i,c)=1;
end

% PART 2: Compute PDFs %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% start matrices (later ncol = k)
Y = [];
N2 = [];

% temp values
Z = zeros([n 1]);
N1 = zeros([n 2]);

% Compute pdf for each k distribution
for c=1:k
    for i=1:n

        % input vector (random)
        N1(i,:) = randn(1, 2);
        % pdf of input vector
        Z(i) = mvlaplace(N1(i,:), mu{c}, sigma{c}, b(c));

    end
    
    % Y has a column for each k distribution
    Y = [Y Z];
    % N2 has d columns for each k distibution
    N2 = [N2 N1];

end

% PART 3: Mix %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% mix PDFs
Y = pick .* Y;
Y = sum(Y, 2);

% mix inputs vectors (X)
pick = [pick(:,1) pick(:,1) pick(:,2) pick(:,2)];
N2 = pick .* N2;
N2 = [N2(:,1) + N2(:,3), N2(:,2) + N2(:,4)];

% PART 4: Plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% lim=3;

% plot
figure(1)
plot3(N2(:,1), N2(:,2), Y, '.')
xlabel('X1');
ylabel('X2');
zlabel('pdf');
% xlim([-lim lim])
% ylim([-lim lim])

%% Simulations for Surfance 3D Plot

% PART 1: Compute PDFs %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rng(123)

% prepare x,y-axis
lim=5;
[X1,X2] = meshgrid(-lim:0.1:lim,-lim:0.1:lim);

% 3D matrix to contain the inputs
X = zeros([size(X1) 2]);
X(:,:,1) = X1;
X(:,:,2) = X2;

% 2D matrix to contain the output
Z = zeros(size(X1));
Y = [];

for c=1:k % CHANGE to k
    for i=1:size(X1, 2)
        for j=1:size(X2, 2)
            Z(i,j) = mvlaplace([X(i,j,1), X(i,j,2)], mu{c}, sigma{c}, b(c));
        end
    end
    Y = [Y Z];
end

% PART 2: Mix %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Prepare mixture
pick=zeros(size(X1));

for i=1:size(X1, 1)
    for j=1:size(X1, 2)

        % MODIFIED
        c = randmultinomial(lambda);

        % If pick == 1,     X2 is taken
        % else,             X1 is taken
        pick(i,j)=c-1;

        % following, pick is for X2 and abs(pick-1) is for X1

    end
end

% mix PDFs
temp1 = Y(:,1:size(Y, 2)/2); temp2 = Y(:,1+size(Y, 2)/2:size(Y, 2));

temp1 = pick .* temp1; temp2 = abs(pick-1) .* temp2;

Z = temp1 + temp2;

% PART 3: Plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(2)
surf(X1,X2,Z)
xlabel('X1');
ylabel('X2');
zlabel('pdf');
xlim([-lim lim])
ylim([-lim lim])

%% Simulations for Surfance 3D Plot, NO MIXTURE

% prepare
lim=3;
[X1,X2] = meshgrid(-lim:0.1:lim,-lim:0.1:lim);

X = zeros([size(X1) 2]);
X(:,:,1) = X1;
X(:,:,2) = X2;
Z = zeros(size(X1));

% compute PDFs
for i=1:size(X1, 2)
    for j=1:size(X2, 2)
        Z(i,j) = mvlaplace([X(i,j,1), X(i,j,2)], [0;0], [1 0; 0 1], 1);
    end
end

% plot
figure(2)
surf(X1,X2,Z)
xlabel('X1');
ylabel('X2');
zlabel('pdf');
xlim([-lim lim])
ylim([-lim lim])
