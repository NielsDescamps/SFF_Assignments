% Assignment4.2.1

n = 1000;
y = zeros(n, 2);
b1 = 2;
b2 = 5;
lambda = 0.7;
mu1 = [5;3];
mu2 = [0;-0.3];
Sigma1 = [3,.75;.75,2];
Sigma2 = [1,.25;.25,.8];

for i = 1:n
    h = rand > lambda;
    y(i,:) = laplacernd(1,b1,mu1,Sigma1).^h .* laplacernd(1,b2,mu2,Sigma2).^(1-h);
end

%%

k=2; d=2; pick=zeros(n,k*d); lambda=[0.7 0.3];

for i=1:n, c=randmultinomial(lambda); pick(i,[c*2-1,c*2])=1; end

Y = [laplacernd(n,b1,mu1,Sigma1) laplacernd(n,b2,mu2,Sigma2)];

Y = [Y(:,1) + Y(:,3) Y(:,2) + Y(:,4)];

%%
[param,stderr,iters,loglik,Varcov] = MVLaplaceMixEstimation(y);
param

%%

names = ["m1.1" "m1.2" "m2.1" "m2.2" "s1.11" "s1.12" "s1.22" "s2.11" "s2.12" "s2.22" "lambda" "b1" "b2"];
true = [mu2' mu1' Sigma2(1:2) Sigma2(2,2) Sigma1(1:2) Sigma1(2,2) lambda b2 b1];
para = [param(3:end)',param(1:2)'];
std_error = real(stderr) + imag(stderr);
std_error = [std_error(3:end);std_error(1:2)]';

format shortG
temp = [true;round(para,2);round(std_error,3)];

tab = array2table(temp,"VariableNames",names,"RowNames",["True","MLE","Std. Error"]);

time = clock;
save("/MATLAB Drive/SFF/Assignment_02/Data/A4_2_BFGS_" + cell2mat(arrayfun(@num2str, [time(1:5),round(time(6))], 'UniformOutput', false)) + ".mat", 'tab')