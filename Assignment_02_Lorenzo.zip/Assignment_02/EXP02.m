
n = 10000;

% Inputs: size, mu, sigma
y = laprnd(n,2,5,3);


%%

mu = mean(y)';

mid=mean(y); sigma=std(y); cv=cov(y); init = [mid(1) mid(2) sigma(1) cv(1,2) sigma(2)]';

%%

b = 2;

old=init;

mu1=old(1); mu2=old(2); s11=old(3); s12=old(4); s22=old(5);

m = diag((y' - [mu1;mu2])' * inv([s11,s12;s12,s22]) * (y' - [mu1;mu2]));

% G^-1
nom = besselk(b-2, sqrt(2*m));
den = sqrt(m/2) .* besselk(b-1, sqrt(2*m));
g = nom ./ den; % (14.38)

% mu
mu = sum((g .* y)', 2) / sum(g);

% sigma
n = size(y,1);
sigma = (y' - mu) * (g .* (y' - mu)') / n;

%%

laplaceEM(y, 2.5)

%%

pd = makedist('Normal','mu',1,'sigma',2);

pdf(pd, 0);
negloglik(pd)

%%
load carsmall;

pd = fitdist(MPG,'tLocationScale','mu',0,'sigma',1,'nu',2);
negloglik(pd)

pd = makedist('tLocationScale');
A = log(pdf(pd, MPG));

A = A( ~any( isnan( A ) | isinf( A ), 2 ),: );
-mean(A)

%%

load carsmall;

p = makedist('tLocationScale','mu',0,'sigma',1,'nu',2);

z = random(p, [1000 2]);

% pd = fitdist(z(:,1),'tLocationScale');
% negloglik(pd)

[param,stderr,iters,loglik,Varcov] = MVTestimation(z);

MVTloglik(param, z)







