function [param,stderr,iters,loglik,Varcov] = MVLaplaceEstimation(x)

    % param: (b, mu1, mu2, Sigma_11, Sigma_12, Sigma_22)
    
    [nobs, d]=size(x); if d~=2, error('not done yet, use EM'), end
    
    % define lower and upper bounds, x0 and 
    if d==2
        
        m1=min(x(:,1)); M1=max(x(:,1)); mid1=(m1+M1)/2;
        m2=min(x(:,2)); M2=max(x(:,2)); mid2=(m2+M2)/2;
        s=sqrt(cov(x)); s11=s(1,1); s12=s(1,2); s22=s(2,2);

        %%%%%%%%        b   mu1  mu2 s11  s12 s22
        bound.lo    = [ 1     0    0 .01  -90 .01 ];
        bound.hi    = [ 30    0    0  90   90  90 ];
        bound.which = [ 1     0    0   1    1   1 ]; % for use in einschrk()
        initvec     = [ 3  mid1 mid2 s11  s12 s22 ];
    end
    
    maxiter=300; tol=1e-7; MaxFunEvals=length(initvec)*maxiter;
    
    opts=optimset('Display','iter','Maxiter',maxiter,'TolFun',tol,'TolX',tol,...
        'MaxFunEvals',MaxFunEvals,'LargeScale','Off');
    
    % pout: values minimizing "fun"
    % fval: value of the objective function "fun"
    % theoutput: information about the optimization process
    % hess: Hessian of "fun" at the solution "pout" (2nd order derivatives)
    [pout,fval,~,theoutput,~,hess]= ...
        fminunc(@(param) MVLAPloglik(param,x,bound),einschrk(initvec,bound),opts);
    
    V=inv(hess)/nobs; % Don't negate because we work with the negative of the loglik
    [param,V]=einschrk(pout,bound,V); % transform and apply delta method to get V
    
    param=param'; Varcov=V; stderr=sqrt(diag(V)); % Approximate standard errors
    loglik=-fval*nobs; iters=theoutput.iterations;

function ll=MVLAPloglik(param,x,bound)

    % if there is no bound, add a bound
    if nargin<3, bound=0; end
    
    % if the bound is structured adjust the standard error
    if isstruct(bound), param=einschrk(real(param),bound,999); end

    [nobs, d]=size(x);
    
    Sig=zeros(d,d); 
    
    b=param(1);
    mu=param(2:3);

    Sig(1,1)=param(4);
    Sig(2,2)=param(6);
    Sig(1,2)=param(5); Sig(2,1)=Sig(1,2);
    
    % if min eigenvalue of Sig is very small
    if min(eig(Sig))<1e-10
        ll=1e5;
    else
        pdf=mvlaplace(x,b,mu',Sig);
        llvec=log(pdf); ll=-mean(llvec); if isinf(ll), ll=1e5; end
    end
