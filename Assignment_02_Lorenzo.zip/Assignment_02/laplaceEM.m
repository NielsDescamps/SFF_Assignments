function [solvec,crit,iter] = laplaceEM(y,b,init,tol,maxit)

if nargin < 5, maxit=5e4; end
if nargin < 4, tol=1e-6; end

outlier=0;

while 1
    % if there is no initial vector
    if nargin < 3
        % set a initial vector
        mid=mean(y); sigma=sqrt(cov(y)); init = [mid(1) mid(2) sigma(1,1) sigma(1,2) sigma(2,2)]';
    end

    [solvec,crit,iter] = hartley(y,b,init,tol,maxit);
    
    % if all estimated parameters are not NA: interrupt
    if all(~isnan(solvec)), break

    % else: eliminate outlier and restart
    else
        y=sort(y) ; left=y(2,:)-y(1,:); right=y(end,:)-y(end-1,:);
        if max(left)>min(right) , y=y(2:end,:); else y=y(1:end-1,:); end
        'removing an outlier ', outlier=outlier+1;
    end
end

% Define "hartley" function
function [solvec,crit,iter] = hartley(y,b,init,tol,maxit)

old=init; new=zeros(5,1); iter=0; crit=0;

while 1
    iter=iter+1;

    mu1=old(1); mu2=old(2); s11=old(3); s12=old(4); s22=old(5);
    
    % m
    m = diag((y' - [mu1;mu2])' * inv([s11,s12;s12,s22]) * (y' - [mu1;mu2]));

    % G^-1
    nom = besselk(b-2, sqrt(2*m));
    den = sqrt(m/2) .* besselk(b-1, sqrt(2*m));
    g = nom ./ den; % (14.38)

    % mu
    mu = sum((g .* y)', 2) / sum(g); new(1) = mu(1); new(2) = mu(2); % (14.36)

    % sigma
    n = size(y,1);
    sigma = (y' - mu) * (g .* (y' - mu)') / n; new(3) = sigma(1,1); new(4) = sigma(1,2); new(5) = sigma(2,2); % (14.36)

    crit = max(abs(old-new)); solvec=new; if any(isnan(solvec)), break, end

    % conditions for interrupting
    if (crit < tol) || (iter >= maxit), break, end
    old=new;
end


