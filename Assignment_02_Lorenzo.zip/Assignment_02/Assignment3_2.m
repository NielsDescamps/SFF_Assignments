%%% Part 3.1

%% Estimate Parameters through MLE

C   = [1 .5; .5 1];
df  = 5;
B   = 100;

df_hat  = zeros([B 1]);
mu1_hat = zeros([B 1]);
mu2_hat = zeros([B 1]);
s11_hat = zeros([B 1]);
s12_hat = zeros([B 1]);
s22_hat = zeros([B 1]);

for i = 1:B
    realisations= mvtrnd(C, df, 1000);
    params      = MVTestimation(realisations);
    df_hat(i)   = params(1);
    mu1_hat(i)  = params(2);
    mu2_hat(i)  = params(3);
    s11_hat(i)  = params(4);
    s12_hat(i)  = params(5);
    s22_hat(i)  = params(6);
end

%% Prepare Plot

params = vertcat(df_hat-5, mu1_hat, mu2_hat, s11_hat-1, s12_hat-.5, s22_hat-1);
temp1 = repelem("df", B);
temp2 = repelem("mu1", B);
temp3 = repelem("mu2", B);
temp4 = repelem("s11", B);
temp5 = repelem("s12", B);
temp6 = repelem("s22", B);
ind = vertcat(temp1', temp2', temp3', temp4', temp5', temp6');

%% Plot

figure(1)
boxplot(params, ind)
title('Boxplot - Parameters MLE of Bivariate Student t')
% hold on
% plot([0.001 10], [0 0], '--', 'Color', 'green', 'LineWidth', 1)
% legend('true ES')
% hold off

%% Part 3.2 %%

%% Simulate from a bivariate Student t

C   = [1 .75; .75 1];
df  = 10;

realisations = mvtrnd(C, df, 10000);

params   = MVTestimation(realisations);
df_hat   = params(1);
mu1_hat  = params(2);
mu2_hat  = params(3);
s11_hat  = params(4);
s12_hat  = params(5);
s22_hat  = params(6);

mu = [mu1_hat; mu2_hat];
sigma = [s11_hat s12_hat; s12_hat s22_hat];

w = 0.5;
a = [w; 1-w];

%%
pf = realisations * a;

[x_ksd,y_ksd] = ksdensity(pf);

figure(2);
plot(y_ksd, x_ksd)

%% Kernel Density

mu_S = a .* mu;
sigma_S = a' .* sigma .* a;

x = sort(realisations * a)';

% manual multivariate Student t pdf
denominator = gamma(df_hat/2) * df_hat * pi * sqrt(det(sigma_S));
nominator2 = gamma((df_hat+2)/2);

% nominator1 = @(x) ( 1 + ([x (si-x)]' - mu_S)' * inv(sigma_S) * ([x (si-x)]' - mu_S) / df_hat )^(-(df_hat+2)/2);
% nominator1 = @(x) ( 1 + (x - mu_S)' * inv(sigma_S) * (x - mu_S) / df_hat )^(-(df_hat+2)/2);

s = sort(realisations * a)';
y = zeros([size(s, 2) 1]);

for i = 1:size(x, 2)

    si = s(i);
    
    nominator1 = @(z) ( 1 + ([z (si-z)]' - mu_S)' * inv(sigma_S) * ([z (si-z)]' - mu_S) / df_hat )^(-(df_hat+2)/2);
    
    temp = integral(nominator1, -Inf, Inf, 'ArrayValued', true) * nominator2 / denominator; % integral(@(x) mvtpdf(x, sigma_S, mu_S), -Inf, Inf); %

    y(i) = temp;

end

y_pdf = y;
s_pdf = s;

% figure(3)
% plot(s_pdf, y_pdf)

%%
figure(4)
plot(s_pdf, y_pdf, 'Color', 'red', 'LineWidth', 1)
hold on
plot(y_ksd, x_ksd, 'Color', 'blue', 'LineWidth', 1)
hold off

%% Inverted Characteristic Function

% fun = @(t) exp(1i .* t .* mu_S) .* besselk(df/2, sqrt(df) .* abs(t) .* k) .* (sqrt(df) .* abs(t) .* k).^(df/2);
% integral(fun, -Inf, Inf) / denominator
% nomimator = exp(1i * t * mu_S) * besselk(df/2, df^.5 * abs(t) * k) * (df^.5 * abs(t) * k)^(df/2);

mu_S = a' * mu;
k = sqrt(a.' * sigma * a);

denominator = gamma(df_hat/2) * 2^(df_hat/2 - 1);
nominator = @(t) exp(1i .* t .* mu_S) .* besselk(df_hat/2, sqrt(df_hat) .* abs(t) .* k) .* (sqrt(df_hat) .* abs(t) .* k).^(df_hat/2);

x = sort(realisations * a)';
y = zeros([size(x, 2) 1]);

for i = 1:size(x, 2)

    xi = x(i);
    
    fun = @(t) exp(-1i .* t .* xi) .* nominator(t);
    
    temp = integral(fun, -Inf, Inf) / ( denominator * 2 * pi);

    y(i) = temp;

end

x_cf = x;
y_cf = y;

plot(x_cf, y_cf)

%%

figure(5)
plot(s_pdf, y_pdf, 'Color', 'green', 'LineWidth', 1)
hold on
plot(y_ksd, x_ksd, 'Color', 'blue', 'LineWidth', 1)
hold on
plot(x_cf, y_cf, 'Color', 'red', 'LineWidth', 1)
hold off
title('Density from Inversion Theorem, Kernel Density Estimate & Density of Sum of r.v.s')
xlabel('Portfolio Value: S = w*X_1 + (1-w)*X_2 for w=' + string(w));
ylabel('pdf');
lgnd = ["PDF of the Sum of the two Assets", "Kernel Density Estimate", "Density from the Inversion Theorem"];
legend(lgnd);
