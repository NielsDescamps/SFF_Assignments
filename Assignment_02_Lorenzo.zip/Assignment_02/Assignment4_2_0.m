% Assigment 4.2

%% Laplace Simulations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

n = 1000;
y = zeros(n, 2);
b1 = 2;
b2 = 3;
lambda = 0.7;
mu1 = [5;4.5];
mu2 = [0;-0.3];
Sigma1 = [3,.75;.75,2];
Sigma2 = [1,.25;.25,.8];

for i = 1:n
    h = rand > lambda;
    y(i,:) = laplacernd(1,b1,mu1,Sigma1).^h .* laplacernd(1,b2,mu2,Sigma2).^(1-h);
end

%%

% (1) Arbitrary values of b1 and b2 are chosen
b=[1.5,3.5];
[solvec,b0,~,~] = mixlaplaceEM_OUT(y,b);

%%

names = ["m1.1" "m1.2" "m2.1" "m2.2" "s1.11" "s1.12" "s1.22" "s2.11" "s2.12" "s2.22" "lambda" "b1" "b2"];
true = [mu1' mu2' Sigma1(1:2) Sigma1(2,2) Sigma2(1:2) Sigma2(2,2) lambda b1 b2];
para = [solvec', b0];

temp = [true;round(para,2)];

tab = array2table(temp,"VariableNames",names,"RowNames",["True","MLE"]);

time = clock;
save("/MATLAB Drive/SFF/Assignment_02/Data/A4_2_table_" + cell2mat(arrayfun(@num2str, [time(1:5),round(time(6))], 'UniformOutput', false)) + ".mat", 'tab')