function [pout,Vout]=einschrk(pin,bound,Vin) 

% pin: parameters vector
% bound: predefined bounds

lo      = bound.lo;
hi      = bound.hi;
welche  = bound.which;

if nargin<3
    trans   = sqrt((hi-pin) ./ (pin-lo));
    pout    = (1-welche) .* pin + welche .* trans;
    Vout    = [];
else

% 1. Transformation to adjust std. errors
trans   = (hi+lo.*pin.^2) ./ (1+pin.^2);

% 2. Return std.-error-adjusted parameters
pout    = (1-welche).* pin + welche .* trans; % now adjust the standard errors
% pin       for bound.which == 0
% trans     for bound.which == 1

% 3. Transform again std. errors
trans   = 2*pin.*(lo-hi) ./ (1+pin.^2).^2;

d   = (1-welche) + welche .* trans; % either unity or delta method.
% unity (==1)           for bound.which == 0
% trans (delta method)  for bound.which == 1

J   = diag(d); 

Vout    = J * Vin * J;

end