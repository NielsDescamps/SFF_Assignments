function [solvec,crit,iter,H1] = mixlaplaceEMqB(y,b,init,tol,maxit)

% if nargin < 5, b=[2,3]; end
if nargin < 5, maxit=5e4; end
if nargin < 4, tol=1e-6; end

outlier=0;

while 1
    % if there is no initial vector
    if nargin < 3
        % set a initial vector
        m=min(y); M=max(y); mid=(m+M)/2; sd=sqrt(cov(y)); init = [mid mid sd(1,:) sd(2,2) sd(1,:)/2 sd(2,2)/2 0.6]';
        % m=min(y); M=max(y); mid=(m+M)/2; sigma=std(y); cv=cov(y); init = [mid mid sigma(1) cv(1,2) sigma(2) sigma(1)/2 cv(1,2) sigma(2)/2 0.6]';
    end

    [solvec,crit,iter,H1] = hartley(y,b,init,tol,maxit);
    
    % if all estimated parameters are not NA: interrupt
    if all(~isnan(solvec)), break

    % else: eliminate outlier and restart
    else
        y=sort(y) ; left=y(2,:)-y(1,:); right=y(end,:)-y(end-1,:);
        if max(left)>min(right) , y=y(2:end,:); else y=y(1:end-1,:); end
        'removing an outlier ', outlier=outlier+1;
    end
end

% Define "hartley" function
function [solvec,crit,iter,H1] = hartley(y,b,init,tol,maxit)

old=init; new=zeros(11,1); iter=0; crit=0;

% quasi-Bayesian priors
omega = 50;
I = eye(2);
J = ones(2);

a1 = 2*omega;
a2 = omega/2;
c1 = 20*omega; c2 = c1;
m1_ = [0;0];
m2_ = -0.1*eye(2);
B1 = (a1/b(1))*((1.5-0.6)*I + 0.6*J);
B2 = (a2/b(2))*((10-4.6)*I + 4.6*J);

while 1
    iter=iter+1;
    
    mu11=old(1); mu12=old(2); mu21=old(3); mu22=old(4);

    s11=old(5); s12=old(6); s22=old(7); s33=old(8); s34=old(9); s44=old(10);
    
    lam=old(11);

    mixn = lam*mvlaplace(y,b(1),[mu11;mu12],[s11,s12;s12,s22])+(1-lam)*mvlaplace(y,b(2),[mu21;mu22],[s33,s34;s34,s44]);
    
    H1=lam*mvlaplace(y,b(1),[mu11;mu12],[s11,s12;s12,s22]) ./ mixn; H2=1-H1; % (14.44)
    
    % m
    m1 = diag((y' - [mu11;mu12]).' * inv([s11,s12;s12,s22]) * (y' - [mu11;mu12]));
    m2 = diag((y' - [mu21;mu22]).' * inv([s33,s34;s34,s44]) * (y' - [mu21;mu22]));
    % G^(-1)
    Xi1 = besselk(b(1)-2, sqrt(2*m1)) ./ ( sqrt(m1/2) .* besselk(b(1)-1, sqrt(2*m1)) ); % (14.52)
    Xi2 = besselk(b(2)-2, sqrt(2*m2)) ./ ( sqrt(m2/2) .* besselk(b(2)-1, sqrt(2*m2)) ); % (14.52)
    % lambda
    new(11) = mean(H1); % (14.48)

    % mu
    temp = (c1*m1_ + y' * (H1 .* Xi1)) ./ (c1 * sum(H1 .* Xi1)); new(1) = temp(1); new(2) = temp(2); % (14.49)
    temp = (c2*m2_ + y' * (H2 .* Xi2)) ./ (c2 * sum(H2 .* Xi2)); new(3) = temp(1); new(4) = temp(2); % (14.49)

    % Sigma 1
    temp = (B1 + (y' - [new(1);new(2)]) * (H1 .* Xi1 .* (y' - [new(1);new(2)])') + c1 * (m1_ - [new(1);new(2)]) * (m1_ - [new(1);new(2)])' ) / (a1 + sum(H1)); % (14.49)
    new(5) = temp(1,1); new(6) = temp(1,2); new(7) = temp(2,2);
    % Sigma 2
    temp = (B2 + (y' - [new(3);new(4)]) * (H2 .* Xi2 .* (y' - [new(3);new(4)])') + c2 * (m2_ - [new(3);new(4)]) * (m2_ - [new(3);new(4)])' ) / (a2 + sum(H2)); % (14.49)
    new(8) = temp(1,1); new(9) = temp(1,2); new(10) = temp(2,2);

    crit = max(abs(old-new)); solvec=new; if any(isnan(solvec)), break, end

    % conditions for interrupting
    if (crit < tol) || (iter >= maxit), break, end
    old=new;
end


