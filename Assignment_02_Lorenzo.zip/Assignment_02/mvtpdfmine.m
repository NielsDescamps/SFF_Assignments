function y = mvtpdfmine(x,df,mu,Sigma)

% Log Likelihood of Multivariate Student't

d=length(x);

if nargin<3, mu = []; end, if isempty(mu), mu = zeros(d,1); end

if nargin<4, Sigma = eye(d); end

x = reshape(x,d,1); mu = reshape(mu,d,1); term = (x-mu)' * inv(Sigma) * (x-mu);

% log likelihood from equation (12.1) & (12.3) of p. 526 of TS book 

logN=-((df+d)/2)*log(1+term/df); logD=0.5*log(det(Sigma))+(d/2)*log(df*pi);

y = exp(gammaln((df+d)/2) - gammaln(df/2) + logN - logD);