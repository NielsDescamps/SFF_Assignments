function C = randmultinomial(p)
% Multinomial Distribution
% a generalisation of the binomial distribution

pp  = cumsum(p);
u   = rand; 
C   = 1+sum(u>pp);