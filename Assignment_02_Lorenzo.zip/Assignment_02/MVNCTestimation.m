function [param,stderr,iters,loglik,Varcov] = MVNCTestimation(x)
    
    % param: (mu1, mu2, g1, g2, nu, Sigma_11, Sigma_12, Sigma_22)
    
    % mu:       d-length location vector
    % mu:       d-length noncentrality vector
    % nu:       degrees of freedom
    % Sigma:    dispersion matrix
    
    [nobs, d]=size(x); if d~=2, error('not done yet, use EM'), end
    
    % define lower and upper bounds, x0 and 
    
     m1=min(x(:,1)); M1=max(x(:,1)); m1=(m1+M1)/2;
     m2=min(x(:,2)); M2=max(x(:,2)); m2=(m2+M2)/2;
     s=sqrt(cov(x)); s11=s(1,1); s12=real(s(1,2)); s22=s(2,2);
    
    if d==2
        %%%%%%%%        mu1  mu2 g1 g2 nu  s11   s12 s22
        bound.lo    = [ 0    0   0  0  0   0.01 -90  0.01 ];
        bound.hi    = [ 0    0   0  0  30  90    90  90   ];
        bound.which = [ 0    0   0  0  1   1     1   1    ]; % for use in einschrk()
        initvec     = [m1   m2   3  5  3   s11   s12 s22  ];
    end
    
    maxiter=300; tol=1e-7; MaxFunEvals=length(initvec)*maxiter;
    
    opts=optimset('Display','iter','Maxiter',maxiter,'TolFun',tol,'TolX',tol,...
        'MaxFunEvals',MaxFunEvals,'LargeScale','Off');
    
    % pout: values minimizing "fun"
    % fval: value of the objective function "fun"
    % theoutput: information about the optimization process
    % hess: Hessian of "fun" at the solution "pout" (2nd order derivatives)
    [pout,fval,~,theoutput,~,hess]= ...
        fminunc(@(param) MVNCTloglik(param,x,bound),einschrk(initvec,bound),opts);
    
    V=inv(hess)/nobs; % Don't negate because we work with the negative of the loglik
    [param,V]=einschrk(pout,bound,V); % transform and apply delta method to get V
    
    param=param'; Varcov=V; stderr=sqrt(diag(V)); % Approximate standard errors
    loglik=-fval*nobs; iters=theoutput.iterations;
    
    function ll=MVNCTloglik(param,x,bound)
    
        % if there is no bound, add a bound
        if nargin<3, bound=0; end
        
        % if the bound is structured adjust the standard error
        if isstruct(bound), param=einschrk(real(param),bound,999); end
    
        [nobs, d]=size(x);
        
        Sigma=zeros(d,d); 
        
        mu1 = param(1);
        mu2 = param(2);
        g1  = param(3);
        g2  = param(4);
        nu  = param(5);
    
        Sigma(1,1)=param(6);
        Sigma(2,2)=param(8);
        Sigma(1,2)=param(7); Sigma(2,1)=Sigma(1,2);
        
        % if min eigenvalue of Sig is very small
        if min(eig(Sigma))<1e-10
            ll=1e5;
        else
            pdf=mvnctpdfln(x', [mu1,mu2], [g1,g2], nu, Sigma);
            llvec=pdf; % llvec=log(pdf); 
            ll=-mean(llvec); if isinf(ll), ll=1e5; end
        end