
n = 5;

y = zeros(n, 2);

for i = 1:n

    h = rand > 0.5;
    y(i,:) = normrnd(0,1, [1 2]);

end

%%

% (0)
n = 1000;
y = zeros(n, 2);
b1 = 2;
b2 = 3;
mu1 = [5;5];
mu2 = [0;0];
Sigma1 = [5,0;0,3];
Sigma2 = [1,0;0,2];

for i = 1:n
    h = rand > 0.3;
    y(i,:) = laplacernd(1,2,b1,mu1,Sigma1).^h .* laplacernd(1,2,b2,mu2,Sigma2).^(1-h);
end

%%

new = zeros(11, 1);
b = [b1;b2];

m=min(y); M=max(y); mid=(m+M)/2; sd=cov(y(:,1),y(:,2)); init = [mid mid sd(1,:) sd(2,2) sd(1,:)/2 sd(2,2)/2 0.6]';

old = init;

mu11=old(1); mu12=old(2); mu21=old(3); mu22=old(4);

s11=old(5); s12=old(6); s22=old(7); s33=old(8); s34=old(9); s44=old(10);
    
lam=old(11);

mixn = lam*mvlaplace(y,b(1),[mu11;mu12],[s11,s12;s12,s22])+(1-lam)*mvlaplace(y,b(2),[mu21;mu22],[s33,s34;s34,s44]);

H1=lam*mvlaplace(y,b(1),[mu11;mu12],[s11,s12;s12,s22]) ./ mixn; H2=1-H1; % (14.44)

m1 = diag((y' - [mu11;mu12]).' * inv([s11,s12;s12,s22]) * (y' - [mu11;mu12]));
m2 = diag((y' - [mu21;mu22]).' * inv([s33,s34;s34,s44]) * (y' - [mu21;mu22]));

Xi1 = besselk(b(1)-2, sqrt(2*m1)) ./ ( sqrt(m1/2) .* besselk(b(1)-1, sqrt(2*m1)) ); % (14.52)
Xi2 = besselk(b(2)-2, sqrt(2*m2)) ./ ( sqrt(m2/2) .* besselk(b(2)-1, sqrt(2*m2)) ); % (14.52)

new(11) = mean(H1); % (14.48)

% mu
temp = y' * (H1 .* Xi1)./ sum(H1 .* Xi1); new(1) = temp(1); new(2) = temp(2); % (14.49)
temp = y' * (H2 .* Xi2) ./ sum(H2 .* Xi2); new(3) = temp(1); new(4) = temp(2); % (14.49)

% Sigma
temp = (y' - [new(1);new(2)]) * (H1 .* Xi1 .* (y' - [new(1);new(2)])') / sum(H1); % (14.49)
new(5) = temp(1,1); new(6) = temp(1,2); new(7) = temp(2,2);
%
temp = (y' - [new(3);new(4)]) * (H2 .* Xi2 .* (y' - [new(3);new(4)])') / sum(H2); % (14.49)
new(8) = temp(1,1); new(9) = temp(1,2); new(10) = temp(2,2);

%% OLD 1-2

temp = H1.' * Xi1 .* (y' - [new(1);new(2)]) * (y' - [new(1);new(2)]).' / sum(H1); new(5) = temp(1,1); new(6) = temp(1,2); new(7) = temp(2,2); % (14.49)
temp = H2.' * Xi2 .* (y' - [new(3);new(4)]) * (y' - [new(3);new(4)]).' / sum(H2); new(8) = temp(1,1); new(9) = temp(1,2); new(10) = temp(2,2); % (14.49)

%% NEW 1

% temp = H1.' * Xi1 .* (y' - [new(1);new(2)]) * (y' - [new(1);new(2)]).' / sum(H1);

num = zeros(2,2,size(H1, 1));
for i=1:size(H1, 1), num(:,:,i) = H1(i) * Xi1(i) * (y(i,:)' - [new(1);new(2)]) * (y(i,:)' - [new(1);new(2)]).'; end
num = cumsum(num, 3); num = num(:,:,end); den = sum(H1); temp = num / den; new(5) = temp(1,1); new(6) = temp(1,2); new(7) = temp(2,2); % (14.49)

%% NEW 2

num = zeros(2,2,size(H2, 1));
for i=1:size(H2, 1), num(:,:,i) = H2(i) * Xi2(i) * (y(i,:)' - [new(3);new(4)]) * (y(i,:)' - [new(3);new(4)]).'; end
num = cumsum(num, 3); num = num(:,:,end); den = sum(H2); temp = num / den; new(8) = temp(1,1); new(9) = temp(1,2); new(10) = temp(2,2); % (14.49)

%%

omega = 50;
I = eye(2);
J = ones(2);

a1 = 2*omega;
a2 = omega/2;
c1 = 20*omega; c2 = c1;
m1_ = [0;0];
m2_ = -0.1*eye(2);
B1 = (a1/b(1))*((1.5-0.6)*I + 0.6*J);
B2 = (a2/b(2))*((10-4.6)*I + 4.6*J);






