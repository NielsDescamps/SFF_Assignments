% Check that besselk() equals the modified Bessel function of the 3rd kind
% (14.30)


%% integral(): single value

nu=1; xi=1;

y = zeros(size(x));

integrand = @(u) u^(nu-1) * exp(-xi/2 * (1/u + u));
0.5 * integral(integrand, 0, Inf, 'ArrayValued', true)
besselk(nu, xi)


%% integral(): multiple values

nu=1;
x = -2:0.1:2;
y1 = zeros(size(x, 2), 1);

for i=1:length(x)
    xi = x(i);
    integrand = @(u) u.^(nu-1) .* exp(-xi./2 .* (1./u + u));
    temp = 0.5 * integral(integrand, 0, Inf, 'ArrayValued', true); % - besselk(nu, xi)) % < 10e-12
    % if temp > 10e3, temp = Inf; end
    y1(i) = temp;
end

y2 = besselk(nu, x)';

% PROBLEM: the integral returns Inf when besselk returns i

abs(y1 - y2)

%% trapz()

x = -2:0.1:2;
y = zeros(size(x, 2), 1);

for i=1:length(x)

    xi = x(i);

    integrand = @(u) u.^(nu-1) .* exp(-xi./2 .* (1./u + u));
    u = 0:0.1:10e1;
    z = 0.5 * integrand(u);
    
    -trapz(z, u)
end


