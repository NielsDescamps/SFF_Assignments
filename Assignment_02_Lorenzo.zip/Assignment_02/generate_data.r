% m <- colmeans( as.matrix( iris[, 1:4] ) )
% s <- cov(iris[,1:4])
% s <- s / det(s)^0.25

m = matrix(c(0,0),1,2)
s = matrix(c(3,.5,.7,2),2,2)
s = s / det(s)^0.25

lam = 1
x = rmvlaplace(100, lam, m, s)
x